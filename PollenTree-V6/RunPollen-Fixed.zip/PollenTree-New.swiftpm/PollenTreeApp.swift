import SwiftUI

@main
struct PollenTreeApp: App {
        var body: some Scene {
                WindowGroup {
                        RootView()
                    }
            }
}


